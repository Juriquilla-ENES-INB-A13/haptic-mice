This folder contains recorded data
